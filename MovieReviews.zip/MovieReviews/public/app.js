
//
// (function(){
//     var app= angular.module("WAM",['ngRoute','textAngular','wbdvDirectives','textAngular']);
// })();

(function () {
    angular
        .module("WDP",['ngRoute']);


})();


